// <!--Global site tag(gtag.js) - Google Analytics-->
window.dataLayer = window.dataLayer || [];
function gtag() { dataLayer.push(arguments); }
gtag('js', new Date());
//----------------------------------------------------

function logoutUserIfLoggedoutFromAnotherTab() {
  window.addEventListener("storage", function (event) {

    if (event.key === "access_token") {
      if (event.newValue === null) {
        goToLoginPageWithLogoutParameter();
      }
      else if (event.oldValue === null) {
        // Open default page of the user.
        location.href = `/account/login`;
      }
    }
  });
}

function goToLoginPageWithLogoutParameter() {
  const encryptedQueryString = btoa("logout=true");
  location.href = `/account/login?query=${encryptedQueryString}`;
}

function main() {
  logoutUserIfLoggedoutFromAnotherTab();
}

main();
