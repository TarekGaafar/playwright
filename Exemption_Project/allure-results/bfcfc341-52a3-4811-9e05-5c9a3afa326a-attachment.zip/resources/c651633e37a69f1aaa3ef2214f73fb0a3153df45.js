abp_dynamic_configuration = {  
        production: false,
        hmr: false,
        application: {
            name: "SaberExemptions",
            logoUrl: "",
            sessionTimeout: 1800
        },
        oAuthConfig: {
            issuer: "https://saberexemption-identity.aks.thiqah.sa",

            get tokenEndpoint() {
            return this.issuer + "/connect/token";
            },
            clientId: "SaberExemptions_App",
            dummyClientSecret: "1q2w3e*",
            scope: "SaberExemptions offline_access",
            showDebugInformation: false,
            oidc: false,
            requireHttps: true,
            strictDiscoveryDocumentValidation: false,
            responseType: "code"
        },
        apis: {
            default: {
                url: "https://saberexemption.aks.thiqah.sa"
            } 
        },
        localization: {
                defaultResourceName: "SaberExemptions"
        } 
    };